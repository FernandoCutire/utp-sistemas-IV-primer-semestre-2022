import darkTheme from "./dom/tema-oscuro.js";

darkTheme(".dark-mode-btn","dark-mode",".stage")
