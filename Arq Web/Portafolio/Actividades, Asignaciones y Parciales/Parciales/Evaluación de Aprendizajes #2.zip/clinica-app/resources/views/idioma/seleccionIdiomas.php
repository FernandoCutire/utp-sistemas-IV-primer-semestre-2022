<?php
include('../includes/header.php');
encabezado();
?>

<?php
include('PedirIdioma.php');
idiomas();


include('../includes/pie_pag.php');
pie();
?>