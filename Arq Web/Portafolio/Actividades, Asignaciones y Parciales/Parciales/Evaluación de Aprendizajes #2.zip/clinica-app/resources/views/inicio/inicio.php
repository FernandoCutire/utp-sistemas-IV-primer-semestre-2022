<?php
include('../includes/header.php');
encabezado();
?>

<?php
include('../formulario/formulario.php');
formulario();

include('../includes/pie_pag.php');
pie();
?>













