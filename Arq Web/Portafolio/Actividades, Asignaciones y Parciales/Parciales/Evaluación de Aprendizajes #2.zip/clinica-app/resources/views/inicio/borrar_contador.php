<?php

setcookie('contador', 1 );
header('location: inicio.php');
?>

