<?php

setcookie('contador', 1);
header('location: /clinica-app/resources/views/inicio/inicio.php');