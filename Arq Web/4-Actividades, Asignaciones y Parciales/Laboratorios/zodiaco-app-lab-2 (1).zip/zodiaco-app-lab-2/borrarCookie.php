<?php
setcookie("idiomaUsuario");
setcookie("contador");
header('location: seleccionIdiomas.php');
?>