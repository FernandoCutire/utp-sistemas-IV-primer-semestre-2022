<?php
include('includes/header_ingles.php');
encabezado();
?>

<?php
include('formulario_ingles.php');
 formulario_ingles();

include('includes/pie_pag_ingles.php');
pie();
?>













