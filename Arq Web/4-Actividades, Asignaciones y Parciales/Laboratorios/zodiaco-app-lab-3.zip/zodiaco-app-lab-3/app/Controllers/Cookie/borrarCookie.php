<?php
setcookie("idiomaUsuario");
setcookie('contador');
header('location: /zodiaco-app/resources/views/idioma/seleccionIdiomas.php');