<?php

setcookie('contador');
header('location: inicio_ingles.php');
