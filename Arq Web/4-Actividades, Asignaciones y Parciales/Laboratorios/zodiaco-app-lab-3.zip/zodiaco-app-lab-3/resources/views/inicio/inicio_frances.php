<?php
include('../includes/header_frances.php');
encabezado();
?>

<?php
include('../formulario/formulario_frances.php');
formulario_frances();

include('../includes/pie_pag_frances.php');
pie();
?>













