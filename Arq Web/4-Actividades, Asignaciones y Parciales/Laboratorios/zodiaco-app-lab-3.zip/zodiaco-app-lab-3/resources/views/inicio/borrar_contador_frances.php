<?php

setcookie('contador');
header('location: inicio_frances.php');
