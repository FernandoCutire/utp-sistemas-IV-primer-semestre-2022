
<?php
	function pie()
	{
    ?>
<footer class="footer">
  <p>Created by: <b>Fernando Cutire & Hellynger St Rose</b></p>
  <p>Architecture and Development of Web Applications</p>
 <p>Assignment 3</p>
   <p>All rights reserved <?php echo date("Y") ?> </p>
</footer>
<?php  }  ?>