
<?php
	function pie()
	{
    ?>
<footer class="footer">
  <p>Créé par: <b>Fernando Cutire & Hellynger St Rose</b></p>
  <p>Architecture et Développement d'Applications Web</p>
 <p> Devoir 3</p>
   <p>Tous droits réservés <?php echo date("Y") ?> </p>
</footer>
<?php  }  ?>