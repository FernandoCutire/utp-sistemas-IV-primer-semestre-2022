
<?php
	function pie()
	{
    ?>
<footer class="footer">
  <p>Creado por: <b>Fernando Cutire & Hellynger St Rose</b></p>
  <p>Arquitectura y Desarrollo de Aplicaciones Web</p>
 <p> Laboratorio 3</p>
   <p>Todos los derechos reservados <?php echo date("Y") ?> </p>
</footer>
<?php  }  ?>